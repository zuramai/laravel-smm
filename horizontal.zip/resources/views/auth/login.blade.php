@extends('layouts.auth')

@section('content')
@section('app_title','Login - '.env('WEB_TITLE'))
<div class="container-fluid">
  <div class="container">
    <div class="row align-items-center">
        <div class="col-lg-6">
            <div>
                <div >
                    <a href="{{ url('/') }}" class="logo logo-admin"><img src="{{env('WEB_LOGO_URL_DARK')}}" height="28" alt="logo"></a>
                </div>
                <h5 class="font-14 text-muted mb-4">{{env("APP_NAME")}}, Website Penyedia Jasa Sosial Media & Pulsa PPOB Terbaik</h5>
                <p class="text-muted mb-4">Dengan bergabung bersama kami, Anda dapat menjadi penyedia jasa social media atau reseller social media seperti jasa penambah Followers, Likes, dll.
                Saat ini tersedia berbagai layanan untuk social media terpopuler seperti Instagram, Facebook, Twitter, Youtube, dll. Dan kamipun juga menyediakan Panel Pulsa & PPOB seperti Pulsa All Operator, Paket Data, Saldo Gojek/Grab, All Voucher Game Online, Dll.</p>

                <h5 class="font-14 text-muted mb-4">Kelebihan {{env('APP_NAME')}} :</h5>
                <div>
                    <p><i class="mdi mdi-arrow-right text-primary mr-2"></i>Harga Instagram Followers mulai dari Rp 100 per 1000</p>
                    <p><i class="mdi mdi-arrow-right text-primary mr-2"></i>Harga Instagram Likes mulai dari Rp 0.</p>
                    <p><i class="mdi mdi-arrow-right text-primary mr-2"></i>Harga Youtube Subscriber mulai dari Rp 10.000 per 1k subscriber</p>
                </div>
            </div>
        </div>
        <div class="col-lg-5 offset-lg-1">
            <div class="card mb-0">
                <div class="card-body">
                    <div class="p-2">
                        <h4 class="text-muted float-right font-18 mt-4">Sign In</h4>
                        <div>
                            <a href="{{ url('/') }}" class="logo logo-admin"><img src="{{env('WEB_LOGO_URL_DARK')}}" height="28" alt="logo"></a>
                        </div>
                    </div>

                    <div class="p-2">
                          @if(session('success'))
                              <div class="alert alert-primary" role="alert">
                                  <i class="fa fa-check-circle"></i> {!! session('success') !!}
                              </div>
                          @elseif(session('danger'))
                            <div class="alert alert-danger" role="alert">
                                <i class="fa fa-exclamation-circle"></i> {!! session('danger') !!}
                            </div>
                          @endif
                        <form class="form-horizontal m-t-20 needs-validation" method="POST" action="#"  novalidate="">
                          @csrf
                            <div class="form-group">
                              <label for="email">Email</label>
                              <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" tabindex="1" required autofocus>
                              @if ($errors->has('email'))
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $errors->first('email') }}</strong>
                                  </span>
                              @endif
                            </div>

                            <div class="form-group">
                              <div class="d-block">
                                <label for="password" class="control-label">Password</label>
                                <div class="float-right">
                                  <a href="{{ url('password/reset') }}" class="text-small">
                                    Forgot Password?
                                  </a>
                                </div>
                              </div>
                              <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" tabindex="2" required>
                              @if ($errors->has('password'))
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $errors->first('password') }}</strong>
                                  </span>
                              @endif
                            </div>

                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="form-group">
                                      <div class="custom-control custom-checkbox">
                                        <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember-me">
                                        <label class="custom-control-label" for="remember-me">Remember Me</label>
                                      </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group text-center row m-t-20">
                                <div class="col-12">
                                    <button class="btn btn-primary btn-block waves-effect waves-light" type="submit">Log In</button>
                                </div>
                            </div>

                            <div class="form-group m-t-10 mb-0 row">
                                <div class="col-sm-7 m-t-20">
                                    <a href="{{ url('password/reset') }}" class="text-muted"><i class="mdi mdi-lock"></i> Forgot your password?</a>
                                </div>
                                <div class="col-sm-5 m-t-20">
                                    <a href="{{route('register')}}" class="text-muted"><i class="mdi mdi-account-circle"></i> Create an account</a>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- end row -->
  </div>
</div>
@endsection
