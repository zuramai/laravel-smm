<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invitation_code extends Model
{
    //
}
